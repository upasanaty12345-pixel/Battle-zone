BATTLE ZONE — Android project (Royal icon)

Is ZIP mein game ka HTML, Android WebView wrapper aur launcher icon shamil hain.
Yeh abhi APK ya Play Store AAB file nahi hai.

BUILD KARNE KE LIYE (parent/guardian ki madad se):
1. Computer par Android Studio install karein.
2. Is ZIP ko extract karke Android Studio mein BATTLE_ZONE_Android_Project folder open karein.
3. Gradle sync complete hone dein. Android SDK Platform 36 aur compatible Build Tools install karne honge.
4. Test ke liye Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Play Store ke liye Build > Generate Signed Bundle / APK > Android App Bundle select karein.
6. Guardian apne Play Console account se signed AAB ko upload karein.

IMPORTANT:
- Package/application ID: com.battlezone.arcade (publish hone ke baad ise badalna mushkil hota hai).
- Version: 1.0 (versionCode 1).
- Is project ko real device par test karein: game start, touch controls, sound, pause, coins/save.
- Play Console ke current target API, testing, privacy/data safety, content rating aur account requirements upload se pehle verify karein.
- Game offline HTML asset se chalta hai; is project mein analytics/ads/login SDK nahi hain.
- Is environment mein Android SDK/Gradle build tools maujood nahi the, isliye yahan AAB/APK compile nahi ki gayi.
